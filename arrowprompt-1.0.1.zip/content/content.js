(function(){"use strict";(function(){const h={enabled:!0,prompts:{ArrowUp:"Explain this code",ArrowDown:"Optimize this",ArrowLeft:"Fix this bug",ArrowRight:"Translate to Chinese"},comboPrompts:[],version:"1.0.0",isPro:!1},P=["ArrowUp","ArrowDown","ArrowLeft","ArrowRight"],D={"claude.ai":{inputSelector:'div[contenteditable="true"], fieldset div[contenteditable="true"]',sendButtonSelector:'button[aria-label*="发送"], button[aria-label*="Send"], button[type="submit"]',type:"contenteditable"},"chat.openai.com":{inputSelector:'#prompt-textarea, textarea[data-id="root"], [data-testid="composer-textarea"], textarea[placeholder*="Message"], form textarea, div[contenteditable="true"][data-id], [contenteditable="true"]',sendButtonSelector:'button[data-testid="send-button"], button[aria-label*="Send"], button[type="submit"], [data-testid="send-button"]',type:"textarea"},"chatgpt.com":{inputSelector:'#prompt-textarea, textarea[data-id="root"], [data-testid="composer-textarea"], textarea[placeholder*="Message"], form textarea, div[contenteditable="true"][data-id], [contenteditable="true"]',sendButtonSelector:'button[data-testid="send-button"], button[aria-label*="Send"], button[type="submit"], [data-testid="send-button"]',type:"textarea"},"perplexity.ai":{inputSelector:'textarea[placeholder*="Ask"], textarea[placeholder*="Message"], textarea[placeholder*="Ask anything"], textarea, div[contenteditable="true"]',sendButtonSelector:'button[type="submit"], button[aria-label*="Send"], button[aria-label*="发送"], button[data-testid="send-button"], [aria-label*="Send"], [role="button"][aria-label*="Send"], button[class*="send"], form button[type="submit"]',type:"textarea"},"gemini.google.com":{inputSelector:'.ql-editor[contenteditable="true"], div[contenteditable="true"][aria-label], rich-textarea div[contenteditable="true"]',sendButtonSelector:'button[aria-label*="Send"], button[aria-label*="发送"], button.send-button',type:"contenteditable"}};let E=!0,u=h;const b=new Set;let x=null;const M=280;function C(t){return[...t].sort()}function z(t){if(t.length<2||t.length>4)return null;const s=[...t].sort().join(",");for(const a of u.comboPrompts){if(a.keys.length<2)continue;if([...a.keys].sort().join(",")===s)return a}return null}function S(){const t=window.location.hostname;for(const[r,s]of Object.entries(D))if(t.includes(r))return s;return null}function B(t,r){const s=t.querySelector(r);if(s)return s;const a=c=>{const l=c.shadowRoot;if(l){const e=l.querySelector(r);if(e)return e;for(const o of l.querySelectorAll("*")){const i=a(o);if(i)return i}}return null};for(const c of t.querySelectorAll("*")){const l=a(c);if(l)return l}return null}function v(){const t=[document];try{document.querySelectorAll("iframe").forEach(r=>{try{const s=r.contentDocument;s&&s!==document&&t.push(s)}catch{}})}catch{}return t}function k(){const t=S();if(!t)return null;const r=window.location.hostname,s=r.includes("chatgpt.com")||r.includes("chat.openai.com"),a=t.inputSelector.split(",").map(o=>o.trim()),c=o=>{for(const i of a){const p=o.querySelector(i);if(p)return p;if(o.body){const n=B(o.body,i);if(n)return n}}return null};let l=c(document);if(l)return l;if(s||r.includes("perplexity.ai")){for(const o of v())if(o!==document&&(l=c(o),l))return l}return null}function L(t){var r;return t.tagName==="TEXTAREA"?"textarea":((r=t.getAttribute)==null?void 0:r.call(t,"contenteditable"))==="true"?"contenteditable":"textarea"}function R(t,r,s){var e;if(!t)return!1;if(window.location.hostname.includes("perplexity.ai"))return setTimeout(()=>{var p;const o=k()??t;if(!o)return;o.focus();const i=L(o);if(i==="contenteditable"){const n=window.getSelection();if(n){const d=document.createRange();d.selectNodeContents(o),d.collapse(!1),n.removeAllRanges(),n.addRange(d);const m=(o.textContent||o.innerText||"").trimEnd().length>0?`
`+r:r;if(!document.execCommand("insertText",!1,m)){const A=(o.textContent||o.innerText||"").trimEnd(),y=A?A+`
`+r:r;o.textContent=y;const f=document.createRange();f.selectNodeContents(o),f.collapse(!1),n.removeAllRanges(),n.addRange(f),o.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:r}))}}}else if(i==="textarea"){const n=o,d=n.value||"",w=d.length>0?d+`
`+r:r,m=(p=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,"value"))==null?void 0:p.set;m?m.call(n,w):n.value=w,n.setSelectionRange(w.length,w.length),o.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:r}))}},0),!0;t.focus();const c=L(t),l=c==="contenteditable"?(t.textContent||t.innerText||"").trimEnd():t.value||"";if(c==="contenteditable"){const o=l,i=o?o+`
`+r:r;t.textContent=i;const p=document.createRange(),n=window.getSelection();p.selectNodeContents(t),p.collapse(!1),n==null||n.removeAllRanges(),n==null||n.addRange(p),t.dispatchEvent(new InputEvent("input",{bubbles:!0,cancelable:!0,inputType:"insertText",data:r}))}else{const o=t,i=o.value||"",p=i.length>0?`
`+r:r,n=i+p,d=(e=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,"value"))==null?void 0:e.set;d?d.call(o,n):o.value=n,o.setSelectionRange(n.length,n.length),t.dispatchEvent(new Event("input",{bubbles:!0}))}return t.dispatchEvent(new Event("change",{bubbles:!0})),t.dispatchEvent(new Event("keyup",{bubbles:!0})),!0}const _={ArrowLeft:"Fix this bug",ArrowRight:"Translate to Chinese",ArrowUp:"Explain this code",ArrowDown:"Optimize this"},$=`
  :host { display: inline-block; pointer-events: none; box-sizing: border-box; }
  .arrowprompt-figma-outer {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    padding: 3.54px;
    gap: 2.02px;
    position: relative;
    background: linear-gradient(180deg, #E9E9E9 0%, #E9E9E9 0.01%, #FFFFFF 100%);
    border-radius: 13.66px;
    height: 75.43px;
    box-sizing: border-box;
  }
  .arrowprompt-neo-button {
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 8.1px;
    width: 112.29px;
    height: 68.35px;
    padding: 4px;
    border: none;
    cursor: default;
    font: inherit;
    background: linear-gradient(180deg, #F4F4F4 0%, #FEFEFE 100%);
    box-shadow: 0px 0px 0.22px 0.22px rgba(0, 0, 0, 0.07), 0px 0px 0.22px 0.67px rgba(0, 0, 0, 0.05), 0px 2.7px 2.92px -1.35px rgba(0, 0, 0, 0.25), 0px 0.9px 3.6px 0.9px rgba(0, 0, 0, 0.12);
    border-radius: 10.12px;
  }
  .arrowprompt-neo-button svg { flex: none; display: block; }
  .arrowprompt-button-text {
    font-family: 'Product Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    font-weight: 400;
    font-size: 12.14px;
    line-height: 110%;
    color: #06071A;
    flex: none;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    max-width: 104.29px;
  }
  .arrowprompt-neo-button-row .arrowprompt-button-text {
    max-width: 120px;
  }
  .arrowprompt-neo-button-row {
    flex-direction: row;
    width: auto;
    min-width: 112.29px;
    height: 68.35px;
  }
  .arrowprompt-figma-outer[data-key="ArrowRight"] {
    width: auto;
    height: auto;
    min-width: 112.29px;
  }
  @keyframes arrowprompt-slideIn {
    from { transform: translateY(6px); opacity: 0; }
    to { transform: translateY(0); opacity: 1; }
  }
  @keyframes arrowprompt-fadeOut {
    to { opacity: 0; transform: translateY(-4px); }
  }
`;function I(t,r,s){const a=r||_[t],c=`<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="none">
  <circle cx="13" cy="2.60001" r="2.60001" fill="#A8A8A8"/>
  <circle cx="13" cy="7.79996" r="2.60001" fill="#A8A8A8"/>
  <circle cx="13" cy="13.0002" r="2.60001" fill="#A8A8A8"/>
  <circle cx="13" cy="18.2001" r="2.60001" fill="#A8A8A8"/>
  <circle cx="13" cy="23.4001" r="2.60001" fill="#A8A8A8"/>
  <circle cx="7.79996" cy="7.79996" r="2.60001" fill="#A8A8A8"/>
  <circle cx="23.4001" cy="13.0002" r="2.60001" fill="#A8A8A8"/>
  <circle cx="2.60001" cy="13.0002" r="2.60001" fill="#A8A8A8"/>
  <circle cx="18.2" cy="7.79996" r="2.60001" fill="#A8A8A8"/>
</svg>`,l=`<span style="display:inline-block;transform:rotate(-90deg);">${c}</span>`,e=`<span style="display:inline-block;transform:rotate(90deg);">${c}</span>`,o=`<svg xmlns="http://www.w3.org/2000/svg" width="26" height="26" viewBox="0 0 26 26" fill="none">
  <circle cx="13.0001" cy="23.4001" r="2.60001" transform="rotate(-180 13.0001 23.4001)" fill="#A8A8A8"/>
  <circle cx="13.0001" cy="18.2001" r="2.60001" transform="rotate(-180 13.0001 18.2001)" fill="#A8A8A8"/>
  <circle cx="13.0001" cy="12.9999" r="2.60001" transform="rotate(-180 13.0001 12.9999)" fill="#A8A8A8"/>
  <circle cx="13.0001" cy="7.79996" r="2.60001" transform="rotate(-180 13.0001 7.79996)" fill="#A8A8A8"/>
  <circle cx="13.0001" cy="2.60001" r="2.60001" transform="rotate(-180 13.0001 2.60001)" fill="#A8A8A8"/>
  <circle cx="18.2002" cy="18.2001" r="2.60001" transform="rotate(-180 18.2002 18.2001)" fill="#A8A8A8"/>
  <circle cx="2.60007" cy="12.9999" r="2.60001" transform="rotate(-180 2.60007 12.9999)" fill="#A8A8A8"/>
  <circle cx="23.4001" cy="12.9999" r="2.60001" transform="rotate(-180 23.4001 12.9999)" fill="#A8A8A8"/>
  <circle cx="7.80014" cy="18.2001" r="2.60001" transform="rotate(-180 7.80014 18.2001)" fill="#A8A8A8"/>
</svg>`,i=`
    <button type="button" class="arrowprompt-neo-button">
      ${c}
      <span class="arrowprompt-button-text">${a}</span>
    </button>
  `,p=`
    <button type="button" class="arrowprompt-neo-button arrowprompt-neo-button-row">
      ${l}
      <span class="arrowprompt-button-text">Fix this bug</span>
    </button>
  `,n=`
    <button type="button" class="arrowprompt-neo-button arrowprompt-neo-button-row">
      <span class="arrowprompt-button-text">${a}</span>
      ${e}
    </button>
  `,d=`
    <button type="button" class="arrowprompt-neo-button">
      <span class="arrowprompt-button-text">${a}</span>
      ${o}
    </button>
  `,w=t==="ArrowUp"?i:t==="ArrowLeft"?p:t==="ArrowRight"?n:d,m=document.createElement("div");m.className="arrowprompt-feedback";const T=m.attachShadow({mode:"open"}),A=document.createElement("style");A.textContent=$,T.appendChild(A);const y=document.createElement("div");y.className="arrowprompt-figma-outer",y.setAttribute("data-key",t),y.innerHTML=w,T.appendChild(y);const f=m;document.body.appendChild(f);const U="1%";f.style.cssText=`
    position: fixed;
    right: ${U};
    bottom: ${U};
    z-index: 999999;
    animation: arrowprompt-slideIn 0.25s ease;
  `,setTimeout(()=>{f.style.animation="arrowprompt-fadeOut 0.2s ease forwards",setTimeout(()=>f.remove(),200)},1800)}function g(t){if(!P.includes(t.key))return;if(!E){console.log("[ArrowPrompt] Extension disabled");return}if(!S()){console.log("[ArrowPrompt] Unsupported website");return}const s=k();if(!s){console.log("[ArrowPrompt] Input field not found");return}if(console.log("[ArrowPrompt] Arrow key detected:",t.key),t.preventDefault(),t.stopPropagation(),b.add(t.key),u.isPro&&b.size>=2){x!==null&&(clearTimeout(x),x=null);const a=z(C(b));if(a&&a.prompt){R(s,a.prompt)&&(console.log("[ArrowPrompt] Combo prompt inserted:",a.prompt),I(t.key,a.prompt));return}}if(b.size===1){x!==null&&clearTimeout(x),x=setTimeout(()=>{if(x=null,b.size!==1)return;const a=k(),c=S();if(!a||!c)return;const l=C(b)[0],e=u.prompts[l]||null;e&&R(a,e)&&(console.log("[ArrowPrompt] Prompt inserted:",e),I(l,e))},M);return}}function H(){const t=document.createElement("style");t.textContent=`
    .arrowprompt-feedback {
      pointer-events: none;
      box-sizing: border-box;
    }
    .arrowprompt-figma-outer {
      display: flex;
      flex-direction: column;
      align-items: flex-start;
      padding: 3.54px;
      gap: 2.02px;
      position: relative;
      background: linear-gradient(180deg, #E9E9E9 0%, #E9E9E9 0.01%, #FFFFFF 100%);
      border-radius: 13.66px;
    }
    .arrowprompt-figma-outer[data-key="ArrowUp"] {
      height: 75.43px;
    }
    .arrowprompt-figma-outer[data-key="ArrowUp"] .arrowprompt-figma-button {
      width: 112.29px;
      height: 68.35px;
    }
    .arrowprompt-figma-outer[data-key="ArrowUp"] .arrowprompt-arrow-wrap {
      width: 26px;
      height: 26px;
    }
    .arrowprompt-figma-outer[data-key="ArrowUp"] .arrowprompt-arrow {
      width: 26px;
      height: 26px;
    }
    .arrowprompt-figma-outer[data-key="ArrowUp"] .arrowprompt-label {
      width: 88px;
      text-align: center;
    }
    .arrowprompt-neo-button {
      box-sizing: border-box;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      gap: 8.1px;
      width: 112.29px;
      height: 68.35px;
      padding: 10.63px 12.14px;
      border: none;
      cursor: default;
      font: inherit;
      background: linear-gradient(180deg, #F4F4F4 0%, #FEFEFE 100%);
      box-shadow: 0px 0px 0.22px 0.22px rgba(0, 0, 0, 0.07), 0px 0px 0.22px 0.67px rgba(0, 0, 0, 0.05), 0px 2.7px 2.92px -1.35px rgba(0, 0, 0, 0.25), 0px 0.9px 3.6px 0.9px rgba(0, 0, 0, 0.12);
      border-radius: 10.12px;
    }
    .arrowprompt-neo-button svg {
      flex: none;
      display: block;
    }
    .arrowprompt-button-text {
      font-family: 'Product Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-weight: 400;
      font-size: 12.14px;
      line-height: 110%;
      color: #06071A;
      flex: none;
      white-space: nowrap;
    }
    .arrowprompt-figma-button {
      box-sizing: border-box;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 10.63px 12.14px;
      gap: 8.1px;
      background: linear-gradient(180deg, #F4F4F4 0%, #FEFEFE 100%);
      box-shadow: 0px 0px 0.22px 0.22px rgba(0, 0, 0, 0.07), 0px 0px 0.22px 0.67px rgba(0, 0, 0, 0.05), 0px 2.7px 2.92px -1.35px rgba(0, 0, 0, 0.25), 0px 0.9px 3.6px 0.9px rgba(0, 0, 0, 0.12);
      border-radius: 10.12px;
      flex: none;
    }
    .arrowprompt-figma-button.arrowprompt-row {
      flex-direction: row;
    }
    .arrowprompt-figma-button.arrowprompt-col {
      flex-direction: column;
    }
    .arrowprompt-arrow-wrap {
      display: flex;
      align-items: center;
      justify-content: center;
      flex: none;
    }
    .arrowprompt-arrow {
      display: block;
      flex: none;
    }
    .arrowprompt-label {
      font-family: 'Product Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      font-style: normal;
      font-weight: 400;
      font-size: 12.14px;
      line-height: 110%;
      color: #06071A;
      flex: none;
      white-space: nowrap;
    }
    @keyframes arrowprompt-slideIn {
      from { transform: translateY(6px); opacity: 0; }
      to { transform: translateY(0); opacity: 1; }
    }
    @keyframes arrowprompt-fadeOut {
      to { opacity: 0; transform: translateY(-4px); }
    }
  `,document.head.appendChild(t)}async function F(){try{const t=await chrome.storage.sync.get(null);return{...h,...t}}catch(t){return console.error("[ArrowPrompt] Failed to load config:",t),h}}function O(){var s,a,c,l;H(),document.addEventListener("keydown",g,!0),window.addEventListener("keydown",g,!0);const t=window.location.hostname;if(t.includes("perplexity.ai")||t.includes("chatgpt.com")||t.includes("chat.openai.com"))for(const e of v())e!==document&&(e.addEventListener("keydown",g,!0),(a=(s=e.defaultView)==null?void 0:s.addEventListener)==null||a.call(s,"keydown",g,!0));chrome.storage.onChanged.addListener((e,o)=>{o==="sync"&&(e.enabled!==void 0&&(E=e.enabled.newValue),e.prompts!==void 0&&(u.prompts=e.prompts.newValue),e.isPro!==void 0&&(u.isPro=e.isPro.newValue),e.comboPrompts!==void 0&&F().then(i=>{u.comboPrompts=Array.isArray(i.comboPrompts)?i.comboPrompts:[]}))}),chrome.runtime.onMessage.addListener(e=>{(e==null?void 0:e.type)==="arrowprompt-reload-config"&&F().then(o=>{u={...h,...o,comboPrompts:Array.isArray(o.comboPrompts)?o.comboPrompts:[]},E=o.enabled})});function r(e){P.includes(e.key)&&b.delete(e.key)}if(document.addEventListener("keyup",r,!0),window.addEventListener("keyup",r,!0),t.includes("perplexity.ai")||t.includes("chatgpt.com")||t.includes("chat.openai.com")){for(const e of v())e!==document&&(e.addEventListener("keyup",r,!0),(l=(c=e.defaultView)==null?void 0:c.addEventListener)==null||l.call(c,"keyup",r,!0));setTimeout(()=>{var e,o,i,p;for(const n of v())n!==document&&(n.addEventListener("keydown",g,!0),n.addEventListener("keyup",r,!0),(o=(e=n.defaultView)==null?void 0:e.addEventListener)==null||o.call(e,"keydown",g,!0),(p=(i=n.defaultView)==null?void 0:i.addEventListener)==null||p.call(i,"keyup",r,!0))},2e3)}F().then(e=>{u={...h,...e,comboPrompts:Array.isArray(e.comboPrompts)?e.comboPrompts:[]},E=e.enabled}).catch(()=>{})}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",O):O()})()})();
